(function() {
  'use strict';

  angular
    .module('dctmFileManagerSample', 
      ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ngMessages', 'ngAria', 'ngResource', 'ui.router', 'dctmNgFileManager', 'ngFileSaver', 'dctmRestClient']);

})();
